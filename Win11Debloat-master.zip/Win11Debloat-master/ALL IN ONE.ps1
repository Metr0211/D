# Get WMI object for computer system
$comsys = Get-WmiObject Win32_ComputerSystem -EnableAllPrivileges

# Check if total physical memory is greater than 17 GB
if ($comsys.TotalPhysicalMemory -gt 17179869184) {
    Write-Host "Disabling Pagefile..."

    # Disable automatic management of the pagefile
    $comsys.AutomaticManagedPagefile = $False
    $comsys.Put()

    # Get WMI object for the pagefile and delete it
    $pagefile = Get-WmiObject -Query "Select * From Win32_PageFileSetting Where Name='c:\\pagefile.sys'"
    $pagefile.Delete()

    Write-Host "Pagefile Disabled. Press Enter to continue..."
    pause
} else {
    Write-Host "Default Pagefile Configuration. Press Enter to continue..."
    pause
}

# Disable USB devices
$power_device_enable = Get-WmiObject MSPower_DeviceEnable -Namespace root\wmi
$usb_devices = @("Win32_USBController", "Win32_USBControllerDevice", "Win32_USBHub")

foreach ($power_device in $power_device_enable) {
    $instance_name = $power_device.InstanceName.ToUpper()
    foreach ($device in $usb_devices) {
        foreach ($hub in Get-WmiObject $device) {
            $pnp_id = $hub.PNPDeviceID
            if ($instance_name -like "*$pnp_id*") {
                $power_device.enable = $False
                $power_device.psbase.put()
            }
        }
    }
}

# Remove unknown PnP devices
$Devices = Get-PnpDevice | ? Status -eq Unknown;
foreach ($Device in $Devices) {
    & "pnputil" /remove-device $Device.InstanceId
}

# Disable USB Power Management in Registry
Get-WmiObject -Class Win32_PnPEntity | Where-Object { $_.DeviceID -like "USB\VID_*" } | ForEach-Object {
    $Path = "HKLM:\System\CurrentControlSet\Enum\$($_.DeviceID)\Device Parameters"
    Reg.exe Add "$Path" /v "EnhancedPowerManagementEnabled" /t REG_DWORD /d "0" /f > $null 2>&1
    Reg.exe Add "$Path" /v "AllowIdleIrpInD3" /t REG_DWORD /d "0" /f > $null 2>&1
    Reg.exe Add "$Path" /v "EnableSelectiveSuspend" /t REG_DWORD /d "0" /f > $null 2>&1
    Reg.exe Add "$Path" /v "DeviceSelectiveSuspended" /t REG_DWORD /d "0" /f > $null 2>&1
    Reg.exe Add "$Path" /v "SelectiveSuspendEnabled" /t REG_DWORD /d "0" /f > $null 2>&1
}

# Disable various power management settings in Registry
Get-ChildItem -Path "HKLM:\System\CurrentControlSet\Enum" -Recurse -ErrorAction SilentlyContinue | Where-Object { $_.Property -contains "IdleInWorkingState" } | ForEach-Object { 
    Reg.exe Add "$_.PSPath" /v "IdleInWorkingState" /t REG_DWORD /d "0" /f > $null 2>&1
}

Get-ChildItem -Path "HKLM:\System\CurrentControlSet\Enum" -Recurse -ErrorAction SilentlyContinue | Where-Object { $_.Property -contains "D3ColdSupported" } | ForEach-Object { 
    Reg.exe Add "$_.PSPath" /v "D3ColdSupported" /t REG_DWORD /d "0" /f > $null 2>&1
}	

Get-ChildItem -Path "HKLM:\System\CurrentControlSet\Enum" -Recurse -ErrorAction SilentlyContinue | Where-Object { $_.Property -contains "EnableIdlePowerManagement" } | ForEach-Object { 
    Reg.exe Add "$_.PSPath" /v "EnableIdlePowerManagement" /t REG_DWORD /d "0" /f > $null 2>&1
}

Get-ChildItem -Path "HKLM:\System\CurrentControlSet\Enum" -Recurse -ErrorAction SilentlyContinue | Where-Object { $_.Property -contains "RemoteWakeEnabled" } | ForEach-Object { 
    Reg.exe Add "$_.PSPath" /v "RemoteWakeEnabled" /t REG_DWORD /d "0" /f > $null 2>&1
}

# Disable USB Link Power Management and Selective Suspend using Powercfg
Powercfg /setacvalueindex scheme_current 2a737441-1930-4402-8d77-b2bebba308a3 d4e98f31-5ffe-4ce1-be31-1b38b384c009 0 > $null 2>&1
Powercfg /setacvalueindex scheme_current 2a737441-1930-4402-8d77-b2bebba308a3 48e6b7a6-50f5-4782-a5d4-53bb8f07e226 0 > $null 2>&1
Powercfg /setdcvalueindex scheme_current 2a737441-1930-4402-8d77-b2bebba308a3 d4e98f31-5ffe-4ce1-be31-1b38b384c009 0 > $null 2>&1
Powercfg /setdcvalueindex scheme_current 2a737441-1930-4402-8d77-b2bebba308a3 48e6b7a6-50f5-4782-a5d4-53bb8f07e226 0 > $null 2>&1
